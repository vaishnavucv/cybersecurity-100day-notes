# cybersecurity-100day-notes
This repo have 100 days of cybersecurity session notes with tools and commands 

## Index
- [Day-01](https://github.com/vaishnavucv/cybersecurity-100day-notes/tree/main/Day-01) intro to cybersecurity + fundamentals
- [Day-02](https://github.com/vaishnavucv/cybersecurity-100day-notes/tree/main/Day-02) Setting up Environment for Ethical Hacking 
